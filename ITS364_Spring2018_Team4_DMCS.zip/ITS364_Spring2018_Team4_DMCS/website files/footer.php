<tr>
	<td colspan="2" style="font-family: 'Century Gothic', Arial, sans-serif; font-weight: bolder; font-size: 0.9em; font-color: #000000;">
		<h2 style="border-top: 2px solid red; padding-top: 10px; font-size: 14px; width: 99%; text-align: center;">
			<span style="border-right: 1px solid #000000; padding-right: 0.7em; padding-left: 0.7em;">1234 Some Street</span>
			<span style="border-right: 1px solid #000000; padding-right: 0.7em; padding-left: 0.7em;">City, State 12345</span>
			<span style="border-right: 1px solid #000000; padding-right: 0.7em; padding-left: 0.7em;">Hotline: 800.123.4567</span> 
			<span style="border-right: 1px solid #000000; padding-right: 0.7em; padding-left: 0.7em;">Support: 800.789.0123</span> 
			<span style="padding-left: 0.7em;"><a href="#">group4@dmcs.org</a></span>
		</h2>
	</td>
</tr>