<tr>
	<td style="text-align: left; padding-left: 1em; padding-top: 0; padding-bottom: 0; padding-right: 0; margin: 0;">
		<table style="border-collapse: collapse;"> <!-- style="border-bottom: 0.1em solid red; width: 100%;" -->
			<tr>
				<td style="padding-top: 1.5em; padding-bottom: 1.5em;">
					You are logged in as <?php echo $_SESSION["currUser"]; ?>.&nbsp;
					<a href="dmcs_index.php?logout=true" style="font-family: 'Century Gothic', Arial, sans-serif; font-weight: bolder; color: #DC143C;">Log Out</a>
				</td>
			</tr>
		</table>
	</td>
</tr>